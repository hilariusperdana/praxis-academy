from django.apps import AppConfig


class AkunConfig(AppConfig):
    name = 'akun'
