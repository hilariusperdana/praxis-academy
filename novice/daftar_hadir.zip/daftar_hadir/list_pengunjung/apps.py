from django.apps import AppConfig


class ListPengunjungConfig(AppConfig):
    name = 'list_pengunjung'
